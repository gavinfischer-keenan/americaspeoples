# Current release verification

Version 0.4.1maintenance release follows the publicly verified0.4.0hybrid release. Current runtime requires HTTP and the Python/SQLite API; file:// checks are historical only.

Run `npm run verify:release` for the ordered current checks, including the extracted self-host bundle and actual API/browser tests. [Code audit](code-audit-2026-10-29.md) records findings and measurements. [Developer guide](developer-guide.md) explains module contracts. [Historical verification](release-verification-history.md) preserves earlier observations without treating them as current guarantees.

Final pass counts, public checks and production release/rollback paths will be appended after verification.


Final source/package verification: all18phases pass, including116unit tests and10PythonAPItests. Fresh independent integration review found no new blocking issue; the conservative circle-edge advisory was fixed. Complete source records, uncertainty and metadata remain covered by exact-export/parity tests. Root before/after measurements and limits are in the code-audit report.
